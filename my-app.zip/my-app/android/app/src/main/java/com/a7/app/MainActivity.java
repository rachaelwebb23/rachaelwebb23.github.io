package com.a7.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
